# ensure that the file can be executed in console
import os, sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from ml_trading.code.config import full_path, features, number_epochs
from ml_trading.code.utils import MLP

import pandas as pd
pd.set_option('display.max_rows', None)
import numpy as np

from sklearn.ensemble import RandomForestClassifier
from sklearn import svm
from sklearn.metrics import precision_score, accuracy_score
from torch.nn.functional import softmax

import random
from ast import literal_eval
from matplotlib import pyplot as plt
from rich import print

import torch
from torch import nn

# Import the best parameters
df_hyperparameter = pd.read_csv(full_path + "data/funds_hyperparameter.csv", index_col=0)
funds_processed = pd.read_csv(full_path + "data/funds_data_processed.csv", index_col=0)

# All models that are selected in the config file
models = df_hyperparameter.Model.unique()
#models = ["svm"]
# Select all tickers for the loop
tickers = list(df_hyperparameter.Ticker.unique())
#tickers = ["IDU"]

# List of model predictions that is merged together later
dfs_predictions = []

# set a seed for replicability
random.seed(3)
np.random.seed(3)
torch.manual_seed(3)


# Define results dataframe
df_results = df_hyperparameter[["Ticker", "Model"]].copy()
df_results["Test_Accuracy"] = np.nan
df_results["Test_Precision"] = np.nan
df_results["Imbalance_Predictions"] = np.nan
df_results["Return_Model"] = np.nan
df_results["Return_Benchmark"] = np.nan



# Get the final test score + Daily Predictions
for ticker in tickers:
    print(f"Ticker: {ticker}")

    # Get the data
    ticker_return = funds_processed[funds_processed["Ticker"] == ticker]

    ticker_train = ticker_return[ticker_return["Type"] == "train"]
    ticker_test = ticker_return[ticker_return["Type"] == "test"]

    X_train = ticker_train[features]
    Y_train = ticker_train["Target_tomorrow"]

    X_test = ticker_test[features]
    Y_test = ticker_test["Target_tomorrow"]

    # Random Forest
    if "random_forest" in models:
        model_rn = "random_forest"

        # get the hyperparameter
        hyper = df_hyperparameter[(df_hyperparameter["Ticker"] == ticker) & (df_hyperparameter["Model"] == model_rn)].Hyperparameter.values[0]
        parameters = literal_eval(hyper)

        # define the model with the best hyperparameters
        model_rf = RandomForestClassifier(n_estimators=parameters[0],
                                          max_depth=parameters[1],
                                          min_samples_split=parameters[2],
                                          min_samples_leaf=parameters[3],
                                          random_state=1)

        # train and predict
        model_rf.fit(X_train, Y_train)

        Y_pred = model_rf.predict(X_test)

        test_accuracy = accuracy_score(Y_test, Y_pred)
        test_precision = precision_score(Y_test, Y_pred, zero_division=0)
        imbalance = (sum(Y_pred) / len(Y_pred)) * 100


        predict_proba = model_rf.predict_proba(X_test)[:, 1]

        # save the predictions
        ticker_results = ticker_test[["Ticker", "Open", "Close", "Target"]].copy()
        ticker_results["Model"] = model_rn
        ticker_results["Prediction"] = Y_pred
        ticker_results["Prediction_Probability"] = predict_proba
        dfs_predictions.append(ticker_results)

        # save the evaluation metrics
        df_results.loc[(df_results['Ticker'] == ticker) & (
                df_results['Model'] == model_rn), 'Test_Accuracy'] = test_accuracy

        df_results.loc[(df_results['Ticker'] == ticker) & (
                df_results['Model'] == model_rn), 'Test_Precision'] = test_precision

        df_results.loc[(df_results['Ticker'] == ticker) & (
                df_results['Model'] == model_rn), 'Imbalance_Predictions'] = imbalance


    if "svm" in models:
        model_rn = "svm"

        # get the hyperparameter
        hyper = df_hyperparameter[(df_hyperparameter["Ticker"] == ticker) & (df_hyperparameter["Model"] == model_rn)].Hyperparameter.values[0]
        parameters = literal_eval(hyper)

        # if Kernel: poly
        if len(parameters) == 4:

            # define the model with the best hyperparameters
            model_svm = svm.SVC(C=parameters[0], kernel=parameters[1], gamma=parameters[2],
                                degree=parameters[3], probability=True, random_state=1)
        else:
            model_svm = svm.SVC(C=parameters[0], kernel=parameters[1], gamma=parameters[2],
                                probability=True, random_state=1)

        # train and predict
        model_svm.fit(X_train, Y_train)
        Y_pred = model_svm.predict(X_test)
        predict_proba = model_svm.predict_proba(X_test)[:, 1]

        test_accuracy = accuracy_score(Y_test, Y_pred)
        test_precision = precision_score(Y_test, Y_pred, zero_division=0)
        imbalance = (sum(Y_pred) / len(Y_pred)) * 100

        # save the predictions
        ticker_results = ticker_test[["Ticker", "Open", "Close", "Target"]].copy()
        ticker_results["Model"] = model_rn
        ticker_results["Prediction"] = Y_pred
        ticker_results["Prediction_Probability"] = predict_proba
        dfs_predictions.append(ticker_results)

        # save the evaluation metrics
        df_results.loc[(df_results['Ticker'] == ticker) & (
                df_results['Model'] == model_rn), 'Test_Accuracy'] = test_accuracy

        df_results.loc[(df_results['Ticker'] == ticker) & (
                df_results['Model'] == model_rn), 'Test_Precision'] = test_precision

        df_results.loc[(df_results['Ticker'] == ticker) & (
                df_results['Model'] == model_rn), 'Imbalance_Predictions'] = imbalance


    if "neural_network" in models:
        model_rn = "neural_network"

        # transform numpy to tensor
        X_train = torch.tensor(X_train.to_numpy(), dtype=torch.float)
        Y_train = torch.tensor(Y_train.to_numpy(), dtype=torch.long)

        X_test = torch.tensor(X_test.to_numpy(), dtype=torch.float)
        Y_test = torch.tensor(Y_test.to_numpy(), dtype=torch.long)

        # number of epochs (config.py)
        number_epochs = number_epochs

        # get the hyperparameter
        hyper = df_hyperparameter[(df_hyperparameter["Ticker"] == ticker) & (df_hyperparameter["Model"] == model_rn)].Hyperparameter.values[0]
        parameters = literal_eval(hyper)

        # define the model with the best hyperparameters
        learning_rate, number_hidden, hidden_dim = parameters

        model_neural = MLP(len(features), 2, hidden_dim, number_hidden)  # input, output, hidden_dim, #layers
        criterion = nn.CrossEntropyLoss()
        optimizer = torch.optim.NAdam(model_neural.parameters(), lr=learning_rate)

        # training
        for epoch in range(number_epochs):
            train_correct = 0
            train_loss = 0

            # Train
            model_neural.train()

            y_pred = model_neural(X_train)[0]
            loss = criterion(y_pred, Y_train)
            loss.backward()
            optimizer.step()

        # prediction
        model_neural.eval()

        running_score = 0
        with torch.no_grad():
            y_pred = model_neural(X_test)[0]
            loss = criterion(y_pred, Y_test)

            _, index = torch.max(y_pred, 1)
            running_score += torch.sum(index == Y_test).item()

        test_accuracy = running_score / len(X_test)
        predicted_labels_np = index.reshape(-1, 1).numpy()  # y_pred
        Y_test_np = Y_test.reshape(-1, 1).numpy()

        imbalance = ((sum(index) / len(index)) * 100).item()
        test_precision = precision_score(Y_test_np, predicted_labels_np, zero_division=0)

        probabilities = softmax(y_pred, dim=1)
        class_1_probabilities = probabilities[:, 1]

        # save the predictions
        ticker_results = ticker_test[["Ticker", "Open", "Close", "Target"]].copy()
        ticker_results["Model"] = model_rn
        ticker_results["Prediction"] = predicted_labels_np
        ticker_results["Prediction_Probability"] = class_1_probabilities.numpy()
        dfs_predictions.append(ticker_results)

        # save the evaluation metrics
        df_results.loc[(df_results['Ticker'] == ticker) & (
                df_results['Model'] == model_rn), 'Test_Accuracy'] = test_accuracy

        df_results.loc[(df_results['Ticker'] == ticker) & (
                df_results['Model'] == model_rn), 'Test_Precision'] = test_precision

        df_results.loc[(df_results['Ticker'] == ticker) & (
                df_results['Model'] == model_rn), 'Imbalance_Predictions'] = imbalance


# combine all ticker dataframes together
df_predictions = pd.concat(dfs_predictions)

# rearrange the columns in df_predictions
df_predictions = df_predictions[["Ticker", "Model", "Open", "Close", "Target", "Prediction", "Prediction_Probability"]].copy()


df_predictions["Signal"] = ['SELL' if x >= 0.5 else 'BUY' for x in df_predictions.Prediction]  # VERTTAUSCHT!!?!?!?!
df_predictions["Original_Signal"] = df_predictions["Signal"]


# Calculate the benchmark return for each ticker
for ticker in tickers:
    subset = df_predictions[(df_predictions["Ticker"] == ticker) & (df_predictions["Model"] == models[0])]
    first_open = subset.iloc[0].Open
    last_close = subset.iloc[-1].Close

    benchmark_return = (last_close - first_open) / first_open

    # add to the results
    df_results.loc[df_results['Ticker'] == ticker, 'Return_Benchmark'] = benchmark_return




### Calculate the model return for each ticker-model combination ###
df_predictions["current_return"] = np.nan

# First: rearrange signals to include the "HOLD" signal
# Second: Do the buy-sell trades
investments = []
dates = []

#


combine_again = []
for ticker in tickers:
    for model in models:

        # First
        subset = df_predictions[(df_predictions["Ticker"] == ticker) & (df_predictions["Model"] == model)].copy()
        subset['Signal'] = subset['Signal'].mask(subset['Signal'].eq('BUY') & subset['Signal'].shift().eq('BUY'), 'HOLD').copy()
        subset['Signal'] = subset['Signal'].mask(subset['Signal'].eq('SELL') & subset['Signal'].shift().eq('SELL'), 'HOLD').copy()

        # sell everything on the last day
        subset.iloc[-1, subset.columns.get_loc("Signal")] = "SELL"





        # Second
        investment = 1
        is_buy = False
        #spread_cost_percent = 0 # 0.00015

        for i in range(len(subset)):

            if subset.iloc[i]["Signal"] == "BUY":
                buy_price = subset.iloc[i]["Open"]
                adjusted_buy_price = buy_price #* (1+spread_cost_percent)
                is_buy = True
                return_rate_b = 0

                subset.iat[i, subset.columns.get_loc('current_return')] = "buy"

            elif subset.iloc[i]["Signal"] == "SELL" and is_buy:

                sell_price = subset.iloc[i]["Open"] # sell Open price
                adjusted_sell_price = sell_price #* (1-spread_cost_percent)

                return_rate = (adjusted_sell_price - adjusted_buy_price) / adjusted_buy_price
                investment *= (1+return_rate)
                subset.iat[i, subset.columns.get_loc('current_return')] = investment
                is_buy = False


        df_results.loc[(df_results['Ticker'] == ticker) & (
                df_results['Model'] == model), 'Return_Model'] = (investment - 1) / 1


        combine_again.append(subset)



df_predictions = pd.concat(combine_again)
df_results["beat"] = df_results.Return_Model > df_results.Return_Benchmark



df_results.to_csv(full_path + "data/funds_final_returns.csv", encoding="utf-8", index=True)



# Plotting

subs = df_predictions[(df_predictions.Ticker == "IYE") & ( df_predictions.Model == "neural_network")]
print(subs)
print(df_results)

subs.index = pd.to_datetime(subs.index)

plt.figure(figsize=(14, 7))
plt.plot(subs.index, subs['Close'], label='Close Price', color='skyblue')
plt.scatter(subs[subs['Signal'] == "SELL"].index, subs[subs['Signal'] == "SELL"]['Close'], label='Sell Signal', color='red', marker='^')
plt.scatter(subs[subs['Signal'] == "BUY"].index, subs[subs['Signal'] == "BUY"]['Close'], label='Buy Signal', color='green', marker='^')


# Initialize holding state and start_date
holding = False
start_date = subs.index[0]

# Add shading for periods where stocks are not held
for i in range(len(subs)):
    if subs['Signal'].iloc[i] == 'BUY' and not holding:
        end_date = subs.index[i]
        # Shade the period of not holding with red color
        plt.axvspan(start_date, end_date, color='red', alpha=0.1)
        start_date = subs.index[i]
        holding = True
    elif subs['Signal'].iloc[i] == 'SELL' and holding:
        end_date = subs.index[i]
        # Shade the period of holding with green color
        plt.axvspan(start_date, end_date, color='green', alpha=0.1)
        start_date = subs.index[i]
        holding = False

# If the last action was a 'BUY', shade until the end of the dataset
if holding:
    plt.axvspan(start_date, subs.index[-1], color='green', alpha=0.1)
else:
    plt.axvspan(start_date, subs.index[-1], color='red', alpha=0.1)



plt.title('Stock Market Predictions with Buy Signals')
plt.xlabel('Date')
plt.ylabel('Close Price')
plt.legend()
plt.grid(True)
plt.xticks(rotation=45)
plt.tight_layout()

plt.show()

